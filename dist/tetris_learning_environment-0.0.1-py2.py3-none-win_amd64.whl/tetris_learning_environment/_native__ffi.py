# auto-generated file
import _cffi_backend

ffi = _cffi_backend.FFI('tetris_learning_environment._native__ffi',
    _version = 0x2601,
    _types = b'',
)
